package www.fiberathome.com.parkingapp.model;

public class Sensors {
    public String icon;
    public String name;
}
