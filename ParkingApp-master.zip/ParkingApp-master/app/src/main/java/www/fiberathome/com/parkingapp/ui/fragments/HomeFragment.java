package www.fiberathome.com.parkingapp.ui.fragments;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ahmadrosid.lib.drawroutemap.DrawMarker;
import com.ahmadrosid.lib.drawroutemap.DrawRouteMaps;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import www.fiberathome.com.parkingapp.GoogleMapWebService.GooglePlaceSearchNearbySearchListener;
import www.fiberathome.com.parkingapp.R;
import www.fiberathome.com.parkingapp.gps.GPSTracker;
import www.fiberathome.com.parkingapp.gps.GPSTrackerListener;
import www.fiberathome.com.parkingapp.model.GlobalVars;
import www.fiberathome.com.parkingapp.model.MyLocation;
import www.fiberathome.com.parkingapp.model.SensorList;
import www.fiberathome.com.parkingapp.module.PlayerPrefs;
import www.fiberathome.com.parkingapp.ui.DialogForm;
import www.fiberathome.com.parkingapp.utils.AppConfig;
import www.fiberathome.com.parkingapp.utils.AppController;

/**
 * A simple {@link Fragment} subclass.
 */



public class HomeFragment extends Fragment implements NavigationView.OnNavigationItemSelectedListener,
        OnMapReadyCallback,
        GooglePlaceSearchNearbySearchListener,
        GoogleMap.OnMarkerClickListener,
        GPSTrackerListener,
        GoogleMap.OnInfoWindowClickListener,
        View.OnClickListener {


    private static final String TAG = HomeFragment.class.getSimpleName();

    // global view
    View view;

    // google map objects
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private GoogleMap googleMap;
    private Marker placeMarker;
    private List<Marker> markers = new ArrayList<>();
    private Marker userLocationMarker;
    private GPSTracker gpsTracker;


    private ProgressDialog progressDialog;
    private Button nearest;
    private Toolbar toolbar;
    private NavigationView navigationView;
    private TextView userFullName;
    private TextView userVehicleNo;
    private ImageView userProfilePic;

    private boolean isGoogleDone = false;
    private boolean isMyServerDone = false;

    private String SensorStatus = "Occupied";
    private String cond = "1";

    public String selectedSensor;
    public String selectedSensorStatus = "Occupied";

    public TextView parkingReqSpot;

    //widgets
    private EditText mSearchText;
    private ImageView mSearchIcon;

    // global distance

    public double nDistance = 132116456;
    public double nLatitude;
    public double nLongitude;

    private static final float DEFAULT_ZOOM = 15f;

    private static final int PERMISSION_REQUEST_CODE_LOCATION = 1;


    public HomeFragment() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        if (checkPermission()){
            showMessage("Permission already grated.");
        }else if (!checkPermission()){
            showMessage("Permission Not Grated!");
            requestPermission();
        }


        MyTimerTask myTask = new MyTimerTask();
        Timer myTimer = new Timer();

        myTimer.schedule(myTask, 5000, 5000);


    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        initialize();
        return view;

    }



    private void init(){
        Log.d(TAG, "init: initializing");

        mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                if(actionId == EditorInfo.IME_ACTION_SEARCH
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || keyEvent.getAction() == KeyEvent.ACTION_DOWN
                        || keyEvent.getAction() == KeyEvent.KEYCODE_ENTER){

                    //execute our method for searching
                    geoLocate();
                }

                return false;
            }
        });
    }

    private void geoLocate(){
        Log.d(TAG, "geoLocate: geolocating");

        String searchString = mSearchText.getText().toString();

        Geocoder geocoder = new Geocoder(getContext());
        List<Address> list = new ArrayList<>();
        try{
            list = geocoder.getFromLocationName(searchString, 1);
        }catch (IOException e){
            Log.e(TAG, "geoLocate: IOException: " + e.getMessage() );
        }

        if(list.size() > 0){
            Address address = list.get(0);

            Log.d(TAG, "geoLocate: found a location: " + address.toString());
            //Toast.makeText(this, address.toString(), Toast.LENGTH_SHORT).show();

            mSearchText.setText(null);

            hideKeyboard(getContext());
            mSearchText.clearFocus();

            moveCamera(new LatLng(address.getLatitude(), address.getLongitude()),
                    DEFAULT_ZOOM);

            MarkerOptions marker = new MarkerOptions().position(new LatLng(address.getLatitude(), address.getLongitude())).title("").icon(BitmapDescriptorFactory.fromResource(R.drawable.mapicon));
            googleMap.addMarker(marker);


        }
    }

    public static void hideKeyboard(Context mContext) {
        InputMethodManager imm = (InputMethodManager) mContext
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(((Activity) mContext).getWindow()
                .getCurrentFocus().getWindowToken(), 0);
    }

    private void moveCamera(LatLng latLng, float zoom){
        Log.d(TAG, "moveCamera: moving the camera to: lat: " + latLng.latitude + ", lng: " + latLng.longitude );
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoom));
    }

    @Override
    public void onResume() {
        super.onResume();
        nearest.setOnClickListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        gpsTracker.stopUsingGPS();
    }

    @Override
    public void onStop() {
        super.onStop();
        gpsTracker.stopUsingGPS();
    }


    private void showMessage(String message) {
        Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();
    }

    private void initialize() {

        mSearchText = (EditText) view.findViewById(R.id.input_search);
        mSearchIcon = (ImageView) view.findViewById(R.id.ic_magnify);


        View locationButton = ((View) view.findViewById(Integer.parseInt("1")).getParent()).findViewById(Integer.parseInt("2"));
        RelativeLayout.LayoutParams rlp = (RelativeLayout.LayoutParams) locationButton.getLayoutParams();
        // position on right bottom
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, 0);
        rlp.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);rlp.setMargins(0,180,30, 0);

        mSearchIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                geoLocate();

            }
        });


        PlayerPrefs.Initialize(getContext());
        initMap();
        initComponents();
        initGPS();
        fetchSensors();
        init();

    }







    /**
     *   Open Dialog Box Method
     */

    public void openDialog(String sId){

        String selectedSpt = sId;

        DialogForm dialogForm = new DialogForm();

        Bundle bundle = new Bundle();
        bundle.putString("selectedSpt", selectedSpt);

        dialogForm.setArguments(bundle);


        dialogForm.show(getFragmentManager(),"dialog form");

    }




    public void fetchSensors(){




            StringRequest strReq = new StringRequest(Request.Method.POST, AppConfig.URL_FETCH_SENSORS, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {

                    Log.e("responce",""+response);

                    googleMap.clear();

                    try {
                        JSONObject object = new JSONObject(response);

                        JSONArray Jarray  = object.getJSONArray("sensors");

                        for (int i = 0; i < Jarray.length(); i++)
                        {
                            JSONObject Jasonobject = Jarray.getJSONObject(i);
                            Log.e("Sensro Info: ", Jasonobject.toString());
                            //Log.e("Sensro Info: ", Jasonobject.get("uid").toString());

                            String latitude1 = Jasonobject.get("latitude").toString();
                            String longitude1 = Jasonobject.get("longitude").toString();


                            // find distance


                            double tDistance = distance(Double.valueOf(latitude1),Double.valueOf(longitude1),GlobalVars.location.latitude,GlobalVars.location.longitude);

                            //Log.e("tDistance:",""+tDistance);
                            if(tDistance < nDistance){
                                nDistance = tDistance;
                                nLatitude = Double.valueOf(latitude1);
                                nLongitude = Double.valueOf(longitude1);
                            }


                            if(Jasonobject.get("s_status").toString().equalsIgnoreCase("1")){

                                if(Jasonobject.get("reserve_status").toString().equalsIgnoreCase("1")){
                                    SensorStatus = "Occupied";
                                    Double lat = Double.parseDouble(latitude1);
                                    Double lon = Double.parseDouble(longitude1);

                                    MarkerOptions marker = new MarkerOptions().position(new LatLng(lat, lon)).title(Jasonobject.get("uid").toString()).snippet("Booked And Parked").icon(BitmapDescriptorFactory.fromResource(R.drawable.mapiconyellow));
                                    googleMap.addMarker(marker);

                                }else{
                                    SensorStatus = "Empty";
                                    Double lat = Double.parseDouble(latitude1);
                                    Double lon = Double.parseDouble(longitude1);

                                    MarkerOptions marker = new MarkerOptions().position(new LatLng(lat, lon)).title(Jasonobject.get("uid").toString()).snippet("Occupied.").icon(BitmapDescriptorFactory.fromResource(R.drawable.mapicon));
                                    googleMap.addMarker(marker);
                                }


                            }else{

                                if(Jasonobject.get("reserve_status").toString().equalsIgnoreCase("1")){
                                    SensorStatus = "Occupied";
                                    Double lat = Double.parseDouble(latitude1);
                                    Double lon = Double.parseDouble(longitude1);

                                    MarkerOptions marker = new MarkerOptions().position(new LatLng(lat, lon)).title(Jasonobject.get("uid").toString()).snippet("Booked but No Vehicle").icon(BitmapDescriptorFactory.fromResource(R.drawable.mapiconblue));
                                    googleMap.addMarker(marker);

                                }else {
                                    SensorStatus = "Empty";
                                    Double lat = Double.parseDouble(latitude1);
                                    Double lon = Double.parseDouble(longitude1);

                                    MarkerOptions marker = new MarkerOptions().position(new LatLng(lat, lon)).title(Jasonobject.get("uid").toString()).snippet("Empty").icon(BitmapDescriptorFactory.fromResource(R.drawable.mapicongreen));
                                    googleMap.addMarker(marker);
                                }

                            }

                        }

                    } catch (JSONException e) {
                        // JSON error
                        e.printStackTrace();
                        //System.out.println(e.getMessage());


                    }
                }
            }, new Response.ErrorListener() {
                @Override


                public void onErrorResponse(VolleyError error) {


                }
            }) {

            };

            AppController.getInstance().addToRequestQueue(strReq);




    }

    private void initMap() {
        if (googleMap == null) {
            SupportMapFragment supportMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
            supportMapFragment.getMapAsync(this);
        }

    }

    /**
     * CHECK PERMISSION FOR: ACCESS FINE LOCATION & ACCESS COARSE LOCATION
     * ===================================================================================
     * if there is not permission granted, just enable the permission.
     */
    private boolean checkPermission(){
        int access_fine_location = ContextCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_FINE_LOCATION);
        int access_coarse_location = ContextCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION);

        if (access_fine_location == PackageManager.PERMISSION_GRANTED && access_coarse_location == PackageManager.PERMISSION_GRANTED){
            return true;
        }else{
            return false;
        }
    }

    /**
     * REQUEST PERMISSION FOR: ACCESS FINE LOCATION & ACCESS COARSE LOCATION
     * ===================================================================================
     * if there is not permission available, just enable the permission.
     */
    private void requestPermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) && ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION)){
            showMessage("GPS permission allows us to access location data. Please allow in App Settings for additional functionality.");
        }else{
            ActivityCompat.requestPermissions(getActivity(), new String[]{
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
            }, PERMISSION_REQUEST_CODE_LOCATION);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case PERMISSION_REQUEST_CODE_LOCATION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    //Snackbar.make(view, "Permission Granted, Now you can access location data.", Snackbar.LENGTH_SHORT).show();
                    showMessage("Permission Granted, Now you can access location data.");
                }else{
                    showMessage("Permission Denied, You cannot access location data.");
                }
                break;
        }
    }

    private void initGPS() {
        gpsTracker = new GPSTracker(getContext(), this);
        if (gpsTracker.canGetLocation()) {
            double latitude = gpsTracker.getLatitude();
            double longitude = gpsTracker.getLongitude();

            if (latitude != 0.0 || longitude != 0.0) {
                GlobalVars.location = new MyLocation(latitude, longitude);
            }
        } else {
            gpsTracker.showSettingsAlert();
        }

    }

    private void initComponents() {
        nearest = view.findViewById(R.id.nearest);
        parkingReqSpot = view.findViewById(R.id.parking_req_spot);

        //nearest.setVisibility(View.INVISIBLE);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;

        refreshUserGPSLocation();
        googleMap.setOnInfoWindowClickListener(this);


    }

    private void refreshUserGPSLocation() {

        if (userLocationMarker != null)
            userLocationMarker.remove();

        GlobalVars.IsFakeGPS = false;
        MyLocation userLocation = GlobalVars.getUserLocation();
        if (userLocation != null) {
            LatLng userLatLng = new LatLng(userLocation.latitude, userLocation.longitude);
            //userLocationMarker = googleMap.addMarker(new MarkerOptions().position(userLatLng).title("Your Location").icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_mylocation)));
            if (ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }

            googleMap.setMyLocationEnabled(true);
            googleMap.getUiSettings().setAllGesturesEnabled(true);
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 18));
            googleMap.setTrafficEnabled(true);

            // Disable: Disable zooming controls
            googleMap.getUiSettings().setZoomControlsEnabled(true);

            // Disable / Disable my location button
            googleMap.getUiSettings().setMyLocationButtonEnabled(true);

            // Enable / Disable Compass icon
            googleMap.getUiSettings().setCompassEnabled(true);

            // Enable / Disable Rotate gesture
            googleMap.getUiSettings().setRotateGesturesEnabled(true);

            // Enable / Disable zooming functionality
            googleMap.getUiSettings().setZoomGesturesEnabled(true);

        }

    }


//    public  void userLocationFAB(View view){
//        FloatingActionButton FAB = view.findViewById(R.id.myLocationButton);
//        FAB.setOnClickListener(new View.OnClickListener() {
//            @SuppressLint("MissingPermission")
//            @Override
//            public void onClick(View view) {
//                if (gpsTracker.canGetLocation()) {
//                    double latitude = gpsTracker.getLatitude();
//                    double longitude = gpsTracker.getLongitude();
//
//                    LatLng latLng = new LatLng(latitude, longitude);
//                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 15);
//                    googleMap.animateCamera(cameraUpdate);
//
//                } else {
//                    gpsTracker.showSettingsAlert();
//                }
//            }
//        });
//    }





    @Override
    public void onGPSTrackerLocationChanged(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();

        //showMessage(latitude + "---" + longitude);

//        if (latitude != 0 || longitude != 0) {
//            GlobalVars.location = new MyLocation(latitude, longitude);
//
//            //LatLng latLng = new LatLng(23.7736563, 90.4149543);
//
//            // create marker
//            //.icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_map_icon)
//
//
//
//
//
//            if (googleMap != null)
//                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(latitude, longitude), 18));
//
//            refreshUserGPSLocation();
//        }

    }


    @Override
    public void onGPSTrackerStatusChanged(String provider, int status, Bundle extras) {
        showMessage("Status Changed");
    }

    /**
     * ONCLICK SECTION
     * @param view
     */
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.nearest:
                // get the nearest sensor information



                nearest.setText("Reverse Spot");


                LatLng coordinate = new LatLng(nLatitude, nLongitude); //Store these lat lng values somewhere. These should be constant.
                CameraUpdate location = CameraUpdateFactory.newLatLngZoom(
                        coordinate, 18);
                googleMap.animateCamera(location);



                //drowRoute(23.778123, 90.415713, 23.774374, 90.415679);




//                if (selectedSensorStatus.equalsIgnoreCase("Empty")) {
//
//
//                    // Sample show notification
//                    Intent intent = new Intent(getContext(), ReserveSpotActivity.class);
//                    intent.putExtra("selectedSpot", selectedSensor);
//                    startActivity(intent);
//                    finish();
//
//                }else {
//                    selectedSensorStatus = "Occupied";
//                    nearest.setText("Find Nearest");
//                }


                break;
        }

    }

    private void finish() {
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }


    @Override
    public void onInfoWindowClick(Marker marker) {
        //Toast.makeText(getContext(),marker.getTitle(),Toast.LENGTH_LONG).show();
        String spotstatus = marker.getSnippet();
        String spotid = marker.getTitle();

        if (spotstatus.equalsIgnoreCase("Empty") || spotstatus.equalsIgnoreCase("Occupied."))
        {
            //Toast.makeText(getContext(),"Sensor details will be shown here..",Toast.LENGTH_SHORT);

            selectedSensor = marker.getTitle();
            Log.e("openDialog", "openDialog");
            openDialog(selectedSensor.toString());



            //R.id.nearest:
            // get the nearest sensor information
            selectedSensor = marker.getTitle().toString();

            //parkingReqSpot.setText(selectedSensor.toString());

            selectedSensorStatus = "Empty";

            nearest.setText("Reverse Spot");
            Toast.makeText(getContext(),marker.getTitle()+" Is Selected For Reservation!",Toast.LENGTH_SHORT).show();

            Log.e("MarkerClick", "Sensor details will be shown here..");
        }else{
            nearest.setText("Find Nearest");
            selectedSensorStatus = "Occupied";
            Toast.makeText(getContext(),marker.getTitle()+" Is already occupied, please an empty parking space.",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onMarkerClick(Marker marker) {

        //Toast.makeText(getContext(),marker.getTitle(),Toast.LENGTH_LONG).show();

//        String spotstatus= marker.getSnippet();
//
//        if (spotstatus.equalsIgnoreCase("Empty"))
//        {
//            Toast.makeText(getContext(),"Sensor details will be shown here..",Toast.LENGTH_SHORT);
//            Log.e("MarkerClick", "Sensor details will be shown here..");
//        }

        return true;
    }

    @Override
    public void onGooglePlaceSearchStart() {

    }

    @Override
    public void onGooglePlaceSearchSuccess(SensorList sensorList) {

    }

// In this class you'd define an instance of your `AsyncTask`

    class MyTimerTask extends TimerTask {
        MyAsyncTask atask;

        @Override
        public void run() {
            //atask = new MyAsyncTask<Void,Void,Void>();
            Log.e("AsyncTask Background: ","AsyncTask Run");



            fetchSensors();


            //atask.execute();

        }

        final class MyAsyncTask extends AsyncTask<Void, Void, Void> {
            @Override
            protected Void doInBackground(Void... voids) {
                Log.e("AsyncTask Background: ","AsyncTask Runn");
                return null;
            }
            // Define here your onPreExecute(), doInBackground(), onPostExecute() methods
            // and whetever you need


        }


    }



   public void drowRoute(Double lat, Double lng, Double dLat, Double dLng){

        LatLng origin = new LatLng(lat, lng);

        LatLng destination = new LatLng(dLat, dLng);

        DrawRouteMaps.getInstance(getActivity(), "@string/google_maps_key")
                .draw(origin, destination, googleMap);
        DrawMarker.getInstance(getContext()).draw(googleMap, origin, R.drawable.marker_a, "Origin Location");
        DrawMarker.getInstance(getContext()).draw(googleMap, destination, R.drawable.marker_b, "Destination Location");

        LatLngBounds bounds = new LatLngBounds.Builder()
                .include(origin)
                .include(destination).build();
        Point displaySize = new Point();

        getActivity().getWindowManager().getDefaultDisplay().getSize(displaySize);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, displaySize.x, 250, 30));
    }


    public double distance(Double latitude, Double longitude, double e, double f) {
        double d2r = Math.PI / 180;

        double dlong = (longitude - f) * d2r;
        double dlat = (latitude - e) * d2r;
        double a = Math.pow(Math.sin(dlat / 2.0), 2) + Math.cos(e * d2r)
                * Math.cos(latitude * d2r) * Math.pow(Math.sin(dlong / 2.0), 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double d = 6367 * c;


        return d;

    }


}


