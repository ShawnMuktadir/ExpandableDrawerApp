package www.fiberathome.com.parkingapp.model;

public class PlaceDetails {
}
