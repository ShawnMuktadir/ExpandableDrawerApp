package www.fiberathome.com.parkingapp.model;

public class KeywordItem {
    public String text;
    public int icon;

    public KeywordItem(String text, int icon) {
        this.text = text;
        this.icon = icon;
    }
}
