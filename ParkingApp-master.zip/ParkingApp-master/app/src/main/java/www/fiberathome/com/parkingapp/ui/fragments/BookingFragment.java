package www.fiberathome.com.parkingapp.ui.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import www.fiberathome.com.parkingapp.R;
import www.fiberathome.com.parkingapp.model.Reservation;
import www.fiberathome.com.parkingapp.model.User;
import www.fiberathome.com.parkingapp.ui.MainActivity;

import www.fiberathome.com.parkingapp.utils.AppConfig;
import www.fiberathome.com.parkingapp.utils.AppController;
import www.fiberathome.com.parkingapp.utils.HttpsTrustManager;
import www.fiberathome.com.parkingapp.utils.SharedPreManager;

import static com.android.volley.VolleyLog.TAG;

/**
 * A simple {@link Fragment} subclass.
 */
public class BookingFragment extends Fragment {


    static int numbRows = 0;

    ListView bookingList;
    ArrayList<String> al;
    ArrayAdapter aa;

    //public static Integer numbRows = 55;


    public BookingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_booking, container, false);

        User user = SharedPreManager.getInstance(getContext()).getUser();

        Objects.requireNonNull(getActivity()).setTitle(user.getFullName());


        fetchBookings(user.getMobileNo());


        bookingList = (ListView) v.findViewById(R.id.booking_list);

        bookingList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String s = al.get(i);

                MainActivity mni = (MainActivity) getActivity();
                mni.f1(s);
            }
        });

        return v;
    }

    public void deowList(ArrayList<String> al){



        al = new ArrayList<String>();

        aa = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_activated_1,al);

        bookingList.setAdapter(aa);

        if(numbRows>0){
            for(Integer i=1;i<=numbRows;i++){
                al.add("Booking "+i+": ");
            }
        }else
            al.add("No Booking Found!");

    }

    public void fetchBookings(final String userId){



        //Log.e("responce",""+userId);

        HttpsTrustManager.allowAllSSL();
        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                AppConfig.URL_FETCH_BOOKINGS, new Response.Listener<String>() {


            @Override
            public void onResponse(String response) {

                //Log.e("responce1",""+response);

                try {
                    JSONObject jsonObject = new JSONObject(response);


                    //Log.e("Booking Object: ", jsonObject.toString());


                    if (!jsonObject.getBoolean("error")){

                        JSONArray Jarray  = jsonObject.getJSONArray("bookings");

                        al = new ArrayList<String>();

                        numbRows = (Integer) Jarray.length();

                        Log.e("Number of Bookings: ", String.valueOf(numbRows));

                        for (int i = 0; i < Jarray.length(); i++)
                        {
                            JSONObject Jasonobject = Jarray.getJSONObject(i);
                            // Log.e("Booking Info: ", Jasonobject.toString());
                            String spotName = Jasonobject.getString("parking_area").toString();
                            String timeStart = Jasonobject.getString("time_start").toString();
                            String timeEnd = Jasonobject.getString("time_end").toString();
                            String currentBill = Jasonobject.getString("current_bill").toString();
                            String previousDue = Jasonobject.getString("penalty").toString();




                            // Log.e("Spot Info: ", spotName.toString());





                            al.add(spotName.toString()+"|"+timeStart.toString()+"|"+timeEnd.toString()+"|"+currentBill.toString()+"|"+previousDue.toString());

                        }

                        deowList(al);


                    }else{
                        al = new ArrayList<String>();
                        al.add(" \n No Booking Found! ");
                        deowList(al);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Log.e("Volley Error", error.getMessage());
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("user_id", userId);
                return params;
            }
        };


        AppController.getInstance().addToRequestQueue(stringRequest, TAG);



    }





}
